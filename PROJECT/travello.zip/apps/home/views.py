from django.http.response import HttpResponse
from django.shortcuts import render

# Create your views here.


def home(request):
    return render(request, 'index.html')


def about(request):
    return HttpResponse("<h1>About Page</h1>")


def contact(request):
    return render(request, 'contact.html')


def details(request):
    return HttpResponse("<h1>Details Page</h1>")